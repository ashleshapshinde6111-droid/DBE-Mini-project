# TODO: Add Payment Option in Bus Pass Management System

- [x] Add Payment model in models.py
- [x] Update Pass model to include payment status
- [x] Add payment routes in app.py
- [x] Create payment.html template
- [x] Update pass_form.html and passes.html for payment integration
